
class AppError(Exception): pass